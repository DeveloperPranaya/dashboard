import styled from 'styled-components';

export const MainWrapper = styled.div`
 display: flex;
 justify-content: center;
 margin-top: 10px 
`;