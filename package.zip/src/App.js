
import './App.css';
import React from "react"
import Dashboard from './pages/dashboard/dashboard';
// import Demo from './pages/dashboard/demo';
import "./style/global.css";

function App() {
 
  return (
    <div style={{width:"100%"}}>
      <Dashboard/>
      {/* <Demo/> */}
    </div>
  );
}

export default App;
